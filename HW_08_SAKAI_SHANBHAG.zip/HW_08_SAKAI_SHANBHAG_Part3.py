
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import math

def readData():
    data = pd.read_csv('HW_PCA_SHOPPING_CART_v896.csv')
    data = data.drop(['ID'], axis=1)
    return np.array(data)
def K_Means_library(data):
    N_CLUSTERS = 6
    kmeans = KMeans(n_clusters = N_CLUSTERS, init = 'k-means++', random_state = 42)
    y_kmeans = kmeans.fit_predict(data)
    print(type(y_kmeans))
    temp = (y_kmeans == 0)
    print(data[y_kmeans == 0, 0])
    print("------------ Clusters at k=6 ------------")
    print(kmeans.cluster_centers_)
    index_x = 0
    index_y = 8
    plt.scatter(data[y_kmeans == 0, index_x], data[y_kmeans == 0, index_y], s = 100, c = 'red', label = 'Cluster 1')
    plt.scatter(data[y_kmeans == 1, index_x], data[y_kmeans == 1, index_y], s = 100, c = 'blue', label = 'Cluster 2')
    plt.scatter(data[y_kmeans == 2, index_x], data[y_kmeans == 2, index_y], s = 100, c = 'green', label = 'Cluster 3')
    plt.scatter(data[y_kmeans == 3, index_x], data[y_kmeans == 3, index_y], s = 100, c = 'cyan', label = 'Cluster 4')
    plt.scatter(data[y_kmeans == 4, index_x], data[y_kmeans == 4, index_y], s = 100, c = 'magenta', label = 'Cluster 5')
    plt.scatter(data[y_kmeans == 5, index_x], data[y_kmeans == 5, index_y], s = 100, c = 'orange', label = 'Cluster 6')
    plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s = 300, c = 'yellow', label = 'Centroids')
    plt.title('Clusters of Customers')
    plt.legend()
    plt.show()

def main():
    data = readData()
    K_Means_library(data)

if __name__ == '__main__':
    main()