Readme.txt
Run the following files for respective parts
Please keep the CSV file in the same location

HW_08_SAKAI_SHANBHAG_Part1.py--Part 1 of the homework(CrossCorrelation)

HW_08_SAKAI_SHANBHAG_Part2.py--Part 2 of the homework(agglomerative clustering)

HW_08_SAKAI_SHANBHAG_Part3.py--Part 3 of the homework(kmeans clustering)

HW_08_SAKAI_SHANBHAG_Writeup.pdf--Write up for the assignment

HW_PCA_SHOPPING_CART_v896.csv--input data



